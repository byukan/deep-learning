import org.apache.sysml.api.mlcontext.MLContext
import org.apache.sysml.api.mlcontext.ScriptFactory.dml

// works in spark-shell only...
val ml = new MLContext(sc)

print ("Spark Version: " + sc.version)
print ("\nSystemML Version: " + ml.version())
print ("\nBuild Time: " + ml.buildTime())

val sumScript = """
X = rand(rows=100, cols=10)
sumX = sum(X)
print(toString(X))
outMatrix = matrix(sumX, rows=1, cols=1)
write(outMatrix, " ", format="csv")
"""

val script = dml(sumScript).out("outMatrix")
val out = ml.execute(script)
val outMatrix = out.getDataFrame("outMatrix")                                         

