val data = 1 to 30

//most RDD operations have identical or nearly identical syntax:
val xrangeRDD = sc.parallelize(data, 25)
val subRDD = xrangeRDD.map(x=> x-1)
val filteredRDD = subRDD.filter(x => x<10)
filteredRDD.collect()
filteredRDD.count()


