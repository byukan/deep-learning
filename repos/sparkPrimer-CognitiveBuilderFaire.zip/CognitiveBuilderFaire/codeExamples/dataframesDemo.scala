import spark.implicits._ //used for $ notation

val df = spark.read.json("people.json")
df.show
df.printSchema

// Register the DataFrame as a SQL temporary view
//df.createGlobalTempView("people")
df.createTempView("people")

//neeed to register dataframe to use (hive like) sql 
println("Query 1: select statements")
df.select("name").show
spark.sql("select name from people").show

println("Query 2: filter statements")
df.filter(df("age") > 21).show
df.filter($"age" > 21).show
spark.sql("select age,name from people where age > 21").show

println("Query 3: group by statements")
df.groupBy("age").count().show
spark.sql("select age, count(age) as count from people group by age").show
