import numpy as np
M, N = 50, 784
H = 16
X = np.random.randn(M, N)# to correct
dZ = np.random.randn(M, H)
W = np.random.randn(N, H)
b = np.random.randn (H)

X.shape, W.shape, b.shape